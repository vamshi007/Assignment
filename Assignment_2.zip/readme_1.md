1. As we already have dockerfile then its time to build the docker image and push it to docker hub
   1. cmd to push the docker image to docker hub are <br>
      1. To tag the docker image
        `docker tag wisecow:latest <your-username>/wisecow:latest`
       example: `docker tag front_end:latest 9440866803/front_end:latest`
      2. pusing the docker image into docker hub
       `docker push <your-username>/wisecow:latest`
       example:`docker push 9440866803/frontend_0001:tagname` 

2. instruction related to k8s <br>
    1. please do check the [backend_deployment.yml](backend_deployment.yml) to view the k8s configuration 
       1. In [backend_deployment.yml](backend_deployment.yml) file contains both service and deployment configuration which has 4 replicas at a time
       2. To run the pods in k8s is `kubectl apply -f [backend_deployment.yml](backend_deployment.yml)`
   2. please do check the [frontend_deployment.yml](frontend_deployment.yml) to view the k8s configuration
        1. In [backend_deployment.yml](backend_deployment.yml)[frontend_deployment.yml](frontend_deployment.yml) file contains both service and deployment configuration which has 4 replicas at a time
       2. To run the pods in k8s is `kubectl apply -f [frontend_deployment.yml](frontend_deployment.yml)`

3. use this command to check weather the deployments are sucessful or not `kubectl get deployments` 

4. To check a simple automation script use the [test_script.py](test_script.py) which contain selenium code which get the title of the webpage. i've provided the simple sample url in the test script. make sure that that you have chrome drives for selenium in your system.

5. [monitor.py](monitor.py)please do check the `monitor.py` for System Health Monitoring Script.

6. [backup.py](backup.py) will take backup of the file in regular intervel of a time.

7. [log_analyzer.py](log_analyzer.py) to analyze the log

8[application_health_checker.py](application_health_checker.py) to check the health of the application


**Note:In python file i've used dummy date <br> and i've used black python libary to organize thge python code**
