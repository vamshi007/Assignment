from selenium import webdriver

driver = webdriver.Chrome()
driver.get('https://www.example.com')
title = driver.title
print(f'Title of the page is: {title}')
driver.quit()
